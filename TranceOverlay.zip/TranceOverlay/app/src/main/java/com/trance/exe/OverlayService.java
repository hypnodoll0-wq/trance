package com.trance.exe;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.graphics.ImageDecoder;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.util.DisplayMetrics;
import android.util.Size;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Draws fading images and words over other apps. Touches pass straight through,
 * so the phone stays usable. Ends when the screen turns off, the phone shuts
 * down, or Stop is tapped. It never restarts by itself.
 */
public class OverlayService extends Service {
    static final String ACTION_STOP = "com.trance.exe.STOP";
    private static final String CHANNEL = "trance_running";

    // {min ms, max ms} between pop-ups for Slow, Medium, Frequent, Rapid, Flood
    private static final int[][] RANGES = {
            {6000, 12000}, {3000, 7000}, {2000, 4000}, {1000, 2000}, {600, 1200}};
    private static final int[] MAX_ACTIVE = {3, 3, 3, 5, 7};
    private static final String[] DEFAULT_WORDS = {"Obey", "Drift", "Goon"};
    // Binaural beat difference between the ears: Delta, Theta, Alpha (Hz)
    private static final double[] BEATS = {3.0, 6.0, 10.0};
    private static final double CARRIER_HZ = 200.0;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Random rnd = new Random();
    private final List<View> active = new ArrayList<>();
    private final List<Uri> uris = new ArrayList<>();
    private final List<Bitmap> builtin = new ArrayList<>();
    private ExecutorService decoder;
    private WindowManager wm;
    private boolean running = false;
    private boolean useWords = true;
    private int freq = 1;
    private String[] words = DEFAULT_WORDS;
    private int audioMode = 3; // 0 off, 1 beat, 2 voice, 3 both
    private int beatIdx = 1;
    private float vol = 0.4f;
    private volatile boolean beating = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    private final BroadcastReceiver screenOff = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            stopSelf();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running) return START_NOT_STICKY;

        startForeground(1, buildNotification());

        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }

        SharedPreferences p = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        freq = Math.max(0, Math.min(4, p.getInt("freq", 1)));
        useWords = p.getBoolean("words", true);
        boolean useBuiltin = p.getBoolean("builtin", true);
        audioMode = Math.max(0, Math.min(3, p.getInt("audio", 3)));
        beatIdx = Math.max(0, Math.min(2, p.getInt("beat", 1)));
        vol = Math.max(0, Math.min(100, p.getInt("vol", 40))) / 100f;
        List<String> ws = new ArrayList<>();
        for (String w : p.getString("wordlist", "Obey, Drift, Goon").split("[,\\n]")) {
            w = w.trim();
            if (!w.isEmpty() && w.length() <= 30) ws.add(w);
            if (ws.size() >= 20) break;
        }
        words = ws.isEmpty() ? DEFAULT_WORDS : ws.toArray(new String[0]);
        Set<String> saved = p.getStringSet("uris", null);
        if (saved != null) for (String s : saved) uris.add(Uri.parse(s));
        if (useBuiltin) {
            builtin.add(spiral(512, 0xFFFF3D9A, 0xFF1B0B36, 0xFF1B0B36, 5));
            builtin.add(spiral(512, 0xFF35E0C5, 0xFF0C1F2E, 0xFF0C1F2E, 6));
            builtin.add(spiral(512, 0xFFF5C542, 0xFF2A0F3D, 0xFF2A0F3D, 4));
        }
        if (uris.isEmpty() && builtin.isEmpty() && !useWords && audioMode == 0) {
            stopSelf();
            return START_NOT_STICKY;
        }

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        decoder = Executors.newSingleThreadExecutor();
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SHUTDOWN);
        registerReceiver(screenOff, f);

        running = true;
        main.postDelayed(loop, 1500);
        startAudio();
        return START_NOT_STICKY;
    }

    private final Runnable loop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            spawn();
            int[] r = RANGES[freq];
            main.postDelayed(this, r[0] + rnd.nextInt(r[1] - r[0]));
        }
    };

    /** Soft sine tones, slightly different in each ear. Needs headphones to be heard as a beat. */
    private void startBeat() {
        final int sr = 44100;
        final double beat = BEATS[beatIdx];
        int min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_STEREO,
                AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) return;
        final AudioTrack t;
        try {
            t = new AudioTrack.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(new AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sr)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                    .setBufferSizeInBytes(Math.max(min, 8192) * 2)
                    .setTransferMode(AudioTrack.MODE_STREAM)
                    .build();
        } catch (Exception e) {
            return;
        }
        t.setVolume(vol);
        beating = true;
        new Thread(() -> {
            try {
                t.play();
                short[] buf = new short[2048 * 2];
                double pl = 0, pr = 0;
                double il = 2 * Math.PI * CARRIER_HZ / sr;
                double ir = 2 * Math.PI * (CARRIER_HZ + beat) / sr;
                double fade = 0, fi = 1.0 / (sr * 3.0); // 3 second fade-in
                while (beating) {
                    for (int i = 0; i < 2048; i++) {
                        if (fade < 1) fade = Math.min(1, fade + fi);
                        buf[2 * i] = (short) (Math.sin(pl) * fade * 19000);
                        buf[2 * i + 1] = (short) (Math.sin(pr) * fade * 19000);
                        pl += il;
                        pr += ir;
                        if (pl > 2 * Math.PI) pl -= 2 * Math.PI;
                        if (pr > 2 * Math.PI) pr -= 2 * Math.PI;
                    }
                    t.write(buf, 0, buf.length);
                }
            } catch (Exception ignored) {
            } finally {
                try {
                    t.stop();
                } catch (Exception ignored) {
                }
                t.release();
            }
        }).start();
    }

    /** Speaks a random word from your list in a slow, low voice using the phone's own speech engine. */
    private final Runnable voiceLoop = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            if (ttsReady && tts != null) {
                Bundle b = new Bundle();
                b.putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, vol);
                tts.speak(words[rnd.nextInt(words.length)], TextToSpeech.QUEUE_FLUSH, b, "trance");
            }
            int lo = freq >= 3 ? 2500 : 4000, hi = freq >= 3 ? 5000 : 9000;
            main.postDelayed(this, lo + rnd.nextInt(hi - lo));
        }
    };

    private void startVoice() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS && tts != null) {
                tts.setPitch(0.6f);
                tts.setSpeechRate(0.7f);
                tts.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
                ttsReady = true;
            }
        });
        main.postDelayed(voiceLoop, 3000);
    }

    private void startAudio() {
        if (audioMode == 1 || audioMode == 3) startBeat();
        if (audioMode == 2 || audioMode == 3) startVoice();
    }

    private Notification buildNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(
                CHANNEL, "Trance.exe running", NotificationManager.IMPORTANCE_LOW));
        PendingIntent stop = PendingIntent.getService(this, 0,
                new Intent(this, OverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Action stopAction = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                "Stop", stop).build();
        return new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Trance.exe is running")
                .setContentText("Tap Stop to end it. It also ends when the screen turns off.")
                .setOngoing(true)
                .addAction(stopAction)
                .build();
    }

    private float r(float a, float b) {
        return a + rnd.nextFloat() * (b - a);
    }

    private void spawn() {
        if (!running || active.size() >= MAX_ACTIVE[freq]) return;
        boolean haveImages = !uris.isEmpty() || !builtin.isEmpty();
        boolean word = useWords && (!haveImages || rnd.nextFloat() < 0.3f);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        final int W = dm.widthPixels, H = dm.heightPixels, m = Math.min(W, H);

        if (word) {
            TextView tv = new TextView(this);
            tv.setText(words[rnd.nextInt(words.length)]);
            tv.setAllCaps(true);
            tv.setTypeface(Typeface.DEFAULT_BOLD);
            tv.setLetterSpacing(0.06f);
            tv.setTextColor(Color.WHITE);
            tv.setShadowLayer(24f, 0f, 0f, 0xFFFF3D9A);
            tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, m * r(0.09f, 0.15f));
            tv.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
                    View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED));
            show(tv, tv.getMeasuredWidth(), tv.getMeasuredHeight(), W, H);
            return;
        }

        final Uri uri = (!uris.isEmpty() && (builtin.isEmpty() || rnd.nextBoolean()))
                ? uris.get(rnd.nextInt(uris.size())) : null;
        final Bitmap bmp = uri == null ? builtin.get(rnd.nextInt(builtin.size())) : null;
        decoder.execute(() -> {
            Drawable d = null;
            try {
                if (uri != null) {
                    d = ImageDecoder.decodeDrawable(
                            ImageDecoder.createSource(getContentResolver(), uri),
                            (dec, info, src) -> {
                                Size s = info.getSize();
                                float sc = Math.min(1f, 720f / Math.max(s.getWidth(), s.getHeight()));
                                dec.setTargetSize(Math.max(1, (int) (s.getWidth() * sc)),
                                        Math.max(1, (int) (s.getHeight() * sc)));
                            });
                } else {
                    d = new BitmapDrawable(getResources(), bmp);
                }
            } catch (Exception e) {
                d = null; // unreadable image: skip this one
            }
            final Drawable fd = d;
            if (fd == null) return;
            main.post(() -> {
                if (!running) return;
                int iw = Math.max(1, fd.getIntrinsicWidth());
                int ih = Math.max(1, fd.getIntrinsicHeight());
                float ratio = iw / (float) ih;
                int w = (int) (m * r(0.38f, 0.7f));
                int h = (int) (w / ratio);
                if (h > H * 0.7f) {
                    h = (int) (H * 0.7f);
                    w = (int) (h * ratio);
                }
                ImageView iv = new ImageView(OverlayService.this);
                iv.setImageDrawable(fd);
                iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
                show(iv, w, h, W, H);
                if (fd instanceof AnimatedImageDrawable) {
                    AnimatedImageDrawable a = (AnimatedImageDrawable) fd;
                    a.setRepeatCount(AnimatedImageDrawable.REPEAT_INFINITE);
                    a.start();
                }
            });
        });
    }

    private void show(final View v, int w, int h, int W, int H) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = (int) r(0, Math.max(1, W - w));
        lp.y = (int) r(0, Math.max(1, H - h));
        v.setAlpha(0f);
        try {
            wm.addView(v, lp);
        } catch (Exception e) {
            stopSelf();
            return;
        }
        active.add(v);
        v.animate().alpha(1f).setDuration(700).start();
        long hold = freq >= 3 ? (long) r(1800, 4000) : (long) r(2800, 6500);
        main.postDelayed(() -> fadeOut(v), hold);
    }

    private void fadeOut(final View v) {
        if (!active.contains(v)) return;
        v.animate().alpha(0f).setDuration(800).withEndAction(() -> remove(v)).start();
    }

    private void remove(View v) {
        if (active.remove(v)) {
            try {
                wm.removeView(v);
            } catch (Exception ignored) {
            }
        }
    }

    @Override
    public void onDestroy() {
        running = false;
        main.removeCallbacksAndMessages(null);
        for (View v : new ArrayList<>(active)) {
            v.animate().cancel();
            remove(v);
        }
        active.clear();
        try {
            unregisterReceiver(screenOff);
        } catch (Exception ignored) {
        }
        beating = false;
        if (tts != null) {
            tts.stop();
            tts.shutdown();
            tts = null;
        }
        if (decoder != null) decoder.shutdownNow();
        // Put the user's own wallpaper back if this run changed it.
        if (WallpaperHelper.isActive(this)) {
            try {
                WallpaperHelper.restore(this);
            } catch (Exception ignored) {
            }
        }
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    /** Two-colour Archimedean spiral, drawn once at start. */
    private static Bitmap spiral(int size, int c1, int c2, int bg, double turns) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(bg);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        float step = (size / 2f) / (float) (turns * 2 * Math.PI);
        p.setStrokeWidth((float) (step * Math.PI * 0.95));
        for (int k = 0; k < 2; k++) {
            p.setColor(k == 0 ? c1 : c2);
            Path path = new Path();
            boolean first = true;
            for (double t = 0.2; t < turns * 2 * Math.PI + 1; t += 0.04) {
                double rad = step * (t + k * Math.PI);
                float x = (float) (size / 2f + rad * Math.cos(t));
                float y = (float) (size / 2f + rad * Math.sin(t));
                if (first) {
                    path.moveTo(x, y);
                    first = false;
                } else {
                    path.lineTo(x, y);
                }
            }
            c.drawPath(path, p);
        }
        return bmp;
    }
}
