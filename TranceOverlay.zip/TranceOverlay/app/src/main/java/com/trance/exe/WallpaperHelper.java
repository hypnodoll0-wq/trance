package com.trance.exe;

import android.Manifest;
import android.app.WallpaperManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.util.DisplayMetrics;
import android.util.Size;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Saves a private copy of the current wallpaper, applies a photo (or lets the
 * spiral live wallpaper take over), and puts the saved wallpaper back afterwards.
 * It never changes the wallpaper unless the copy was saved and checked first.
 */
final class WallpaperHelper {
    private static final String FILE_SYSTEM = "orig_system.img";
    private static final String FILE_LOCK = "orig_lock.img";

    private WallpaperHelper() {
    }

    /** Reading the current wallpaper needs file access on Android. */
    static boolean canReadWallpaper(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_GRANTED;
    }

    static boolean isActive(Context c) {
        return c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getBoolean("wp_active", false);
    }

    /**
     * Step 1 of changing the wallpaper: save the current one, then (for a photo)
     * apply it. Returns null on success, otherwise a message for the user. When a
     * message comes back, the wallpaper has not been touched.
     */
    static String prepare(Context c, int mode, Uri photo) {
        WallpaperManager wm = WallpaperManager.getInstance(c);
        if (!wm.isWallpaperSupported() || !wm.isSetWallpaperAllowed()) {
            return "This phone doesn't let apps change the wallpaper.";
        }
        if (!canReadWallpaper(c)) {
            return "Allow wallpaper access first, so your current wallpaper can be saved.";
        }
        SharedPreferences p = c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE);
        File sys = new File(c.getFilesDir(), FILE_SYSTEM);
        File lock = new File(c.getFilesDir(), FILE_LOCK);

        // Keep an existing copy if a previous run never got restored.
        if (!p.getBoolean("wp_active", false) || !sys.exists()) {
            if (wm.getWallpaperInfo() != null) {
                return "You're using a live wallpaper. Switch to a normal one first so it can be put back exactly.";
            }
            if (!saveCopy(wm, WallpaperManager.FLAG_SYSTEM, sys) || !looksLikeImage(sys)) {
                sys.delete();
                return "Couldn't save your current wallpaper, so I left it alone.";
            }
            lock.delete();
            if (!saveCopy(wm, WallpaperManager.FLAG_LOCK, lock) || !looksLikeImage(lock)) {
                lock.delete();
            }
        }

        if (mode == 2) {
            if (photo == null) return "Choose a background photo first.";
            try {
                final DisplayMetrics dm = c.getResources().getDisplayMetrics();
                Bitmap bmp = ImageDecoder.decodeBitmap(
                        ImageDecoder.createSource(c.getContentResolver(), photo),
                        (dec, info, src) -> {
                            Size s = info.getSize();
                            float longSide = Math.max(dm.widthPixels, dm.heightPixels);
                            float sc = Math.min(1f, longSide / Math.max(s.getWidth(), s.getHeight()));
                            dec.setTargetSize(Math.max(1, (int) (s.getWidth() * sc)),
                                    Math.max(1, (int) (s.getHeight() * sc)));
                            dec.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
                        });
                wm.setBitmap(bmp, null, true,
                        WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            } catch (Exception e) {
                return "Couldn't set that photo as your wallpaper.";
            }
        }
        p.edit().putBoolean("wp_active", true).apply();
        return null;
    }

    /** Puts the saved wallpaper back. Returns true when it worked. */
    static boolean restore(Context c) {
        File sys = new File(c.getFilesDir(), FILE_SYSTEM);
        File lock = new File(c.getFilesDir(), FILE_LOCK);
        if (!sys.exists()) return false;
        WallpaperManager wm = WallpaperManager.getInstance(c);
        try {
            int first = lock.exists()
                    ? WallpaperManager.FLAG_SYSTEM
                    : (WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
            try (InputStream in = new FileInputStream(sys)) {
                wm.setStream(in, null, true, first);
            }
            if (lock.exists()) {
                try (InputStream in = new FileInputStream(lock)) {
                    wm.setStream(in, null, true, WallpaperManager.FLAG_LOCK);
                }
            }
        } catch (Exception e) {
            return false;
        }
        sys.delete();
        lock.delete();
        c.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean("wp_active", false).apply();
        return true;
    }

    private static boolean saveCopy(WallpaperManager wm, int which, File dest) {
        try (ParcelFileDescriptor pfd = wm.getWallpaperFile(which)) {
            if (pfd == null) return false;
            try (InputStream in = new FileInputStream(pfd.getFileDescriptor());
                 OutputStream out = new FileOutputStream(dest)) {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            return dest.length() > 0;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean looksLikeImage(File f) {
        if (!f.exists()) return false;
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(f.getAbsolutePath(), o);
        return o.outWidth > 0 && o.outHeight > 0;
    }
}
