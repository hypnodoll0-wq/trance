package com.trance.exe;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;

/** A slowly turning spiral. Used as the optional "Spinning spiral" background. */
public class SpiralWallpaperService extends WallpaperService {

    @Override
    public Engine onCreateEngine() {
        return new SpiralEngine();
    }

    private class SpiralEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
        private Bitmap spiral;
        private float angle = 0f;
        private long last;
        private boolean visible = false;

        private final Runnable frame = this::drawFrame;

        @Override
        public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            spiral = makeSpiral(1024, 0xFFE0347F, 0xFF120A24, 6);
        }

        @Override
        public void onVisibilityChanged(boolean v) {
            visible = v;
            handler.removeCallbacks(frame);
            if (v) {
                last = SystemClock.uptimeMillis();
                handler.post(frame);
            }
        }

        @Override
        public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(frame);
            super.onSurfaceDestroyed(holder);
        }

        @Override
        public void onDestroy() {
            visible = false;
            handler.removeCallbacks(frame);
            super.onDestroy();
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null && spiral != null) {
                    int w = c.getWidth(), h = c.getHeight();
                    c.drawColor(0xFF07040F);
                    float scale = (float) Math.hypot(w, h) / spiral.getWidth();
                    c.save();
                    c.translate(w / 2f, h / 2f);
                    c.rotate(angle);
                    c.scale(scale, scale);
                    c.drawBitmap(spiral, -spiral.getWidth() / 2f, -spiral.getHeight() / 2f, paint);
                    c.restore();
                }
            } finally {
                if (c != null) holder.unlockCanvasAndPost(c);
            }
            long now = SystemClock.uptimeMillis();
            angle = (angle + (now - last) * 0.001f * 16f) % 360f; // 16 degrees per second
            last = now;
            if (visible) handler.postDelayed(frame, 33);
        }
    }

    private static Bitmap makeSpiral(int size, int c1, int c2, double turns) {
        Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bmp);
        c.drawColor(c2);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setStyle(Paint.Style.STROKE);
        float step = (size / 2f) / (float) (turns * 2 * Math.PI);
        p.setStrokeWidth((float) (step * Math.PI * 0.95));
        for (int k = 0; k < 2; k++) {
            p.setColor(k == 0 ? c1 : c2);
            Path path = new Path();
            boolean first = true;
            for (double t = 0.2; t < turns * 2 * Math.PI + 1; t += 0.04) {
                double rad = step * (t + k * Math.PI);
                float x = (float) (size / 2f + rad * Math.cos(t));
                float y = (float) (size / 2f + rad * Math.sin(t));
                if (first) {
                    path.moveTo(x, y);
                    first = false;
                } else {
                    path.lineTo(x, y);
                }
            }
            c.drawPath(path, p);
        }
        return bmp;
    }
}
