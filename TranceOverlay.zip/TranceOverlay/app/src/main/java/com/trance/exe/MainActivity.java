package com.trance.exe;

import android.Manifest;
import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.text.InputType;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    static final String PREFS = "trance";
    private static final int REQ_PICK = 1;
    private static final int REQ_NOTIF = 2;
    private static final int REQ_WP = 3;
    private static final int REQ_STORAGE = 4;
    private static final int BG = 0xFF0A0714, PANEL = 0xFF150E28, LINE = 0xFF2C2150,
            FG = 0xFFF1ECFF, DIM = 0xFF9A8FC0, ACCENT = 0xFFFF3D9A, SIGNAL = 0xFF35E0C5;
    private static final String[] FREQ = {
            "Slow (every 6 to 12 s)", "Medium (every 3 to 7 s)", "Frequent (every 2 to 4 s)",
            "Rapid (every 1 to 2 s)", "Flood (every 0.6 to 1.2 s)"};

    private SharedPreferences prefs;
    private TextView status;
    private RadioGroup freqGroup;
    private CheckBox cbBuiltin, cbWords;
    private RadioGroup soundGroup, beatGroup;
    private SeekBar volBar;
    private EditText wordsEt;
    private RadioGroup wpGroup;
    private static final String[] WP = {"Keep my wallpaper", "Spinning spiral", "My photo"};
    private static final String[] SOUND = {"Off", "Binaural beat", "Spoken words", "Beat and spoken words"};
    private static final String[] BEAT = {"Delta, 3 Hz (heavy)", "Theta, 6 Hz (deep)", "Alpha, 10 Hz (calm)"};

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Trance.exe", 36, FG, true);
        SpannableString ss = new SpannableString("Trance.exe");
        ss.setSpan(new ForegroundColorSpan(ACCENT), 6, 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        title.setText(ss);
        root.addView(title);

        root.addView(text("A harmless pretend virus. It drops images, GIFs and words over your other "
                + "apps at random moments. Touches pass straight through, so your phone stays usable. "
                + "It ends when the screen turns off or you tap Stop.", 14, DIM, false), topMargin(8));

        root.addView(text("Pop-ups fade in and out slowly and never strobe. Skip this app if "
                + "flashing or spinning visuals bother you.", 13, DIM, false), topMargin(12));

        root.addView(button("1. Allow display over other apps", false, v -> {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }), topMargin(22));

        root.addView(button("2. Add images or GIFs", false, v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_PICK);
        }), topMargin(10));

        root.addView(button("Clear my images", false, v -> {
            prefs.edit().remove("uris").apply();
            refresh("Images cleared.");
        }), topMargin(10));

        root.addView(text("HOW OFTEN", 12, DIM, false), topMargin(22));
        freqGroup = new RadioGroup(this);
        freqGroup.setOrientation(RadioGroup.VERTICAL);
        int saved = prefs.getInt("freq", 1);
        for (int i = 0; i < FREQ.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(FREQ[i]);
            rb.setTextColor(FG);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            freqGroup.addView(rb);
        }
        freqGroup.check(1000 + Math.max(0, Math.min(FREQ.length - 1, saved)));
        root.addView(freqGroup, topMargin(4));

        cbBuiltin = check("Include built-in spirals", prefs.getBoolean("builtin", true));
        cbWords = check("Include drifting words", prefs.getBoolean("words", true));
        root.addView(cbBuiltin, topMargin(8));
        root.addView(cbWords, topMargin(2));

        root.addView(text("SOUND", 12, DIM, false), topMargin(22));
        soundGroup = radios(SOUND, 2000, prefs.getInt("audio", 3));
        root.addView(soundGroup, topMargin(4));

        root.addView(text("BEAT SPEED", 12, DIM, false), topMargin(14));
        beatGroup = radios(BEAT, 3000, prefs.getInt("beat", 1));
        root.addView(beatGroup, topMargin(4));

        root.addView(text("VOLUME (keep it low; binaural beats need headphones)", 12, DIM, false), topMargin(14));
        volBar = new SeekBar(this);
        volBar.setMax(100);
        volBar.setProgress(prefs.getInt("vol", 40));
        root.addView(volBar, topMargin(4));

        root.addView(text("WORDS (spoken and shown, separate with commas)", 12, DIM, false), topMargin(14));
        wordsEt = new EditText(this);
        wordsEt.setText(prefs.getString("wordlist", "Obey, Drift, Goon"));
        wordsEt.setTextColor(FG);
        wordsEt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        wordsEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        wordsEt.setPadding(dp(12), dp(10), dp(12), dp(10));
        GradientDrawable eg = new GradientDrawable();
        eg.setCornerRadius(dp(10));
        eg.setColor(PANEL);
        eg.setStroke(dp(1), LINE);
        wordsEt.setBackground(eg);
        root.addView(wordsEt, topMargin(4));

        root.addView(text("BACKGROUND", 12, DIM, false), topMargin(22));
        wpGroup = radios(WP, 4000, prefs.getInt("wp", 0));
        root.addView(wpGroup, topMargin(4));
        root.addView(text("Before changing anything, Trance.exe saves a private copy of your current "
                + "wallpaper (this needs wallpaper access). If it can't save a copy, it leaves your "
                + "wallpaper alone. Your wallpaper comes back when you tap Stop or the screen turns off.",
                13, DIM, false), topMargin(8));
        root.addView(button("Allow wallpaper access", false, v -> openStorageAccess()), topMargin(10));
        root.addView(button("Choose background photo", false, v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_WP);
        }), topMargin(10));
        root.addView(button("Restore my wallpaper", false, v -> {
            refresh("Restoring...");
            new Thread(() -> {
                final boolean ok = WallpaperHelper.restore(this);
                runOnUiThread(() -> refresh(ok ? "Your wallpaper is back."
                        : "There's no saved wallpaper to restore."));
            }).start();
        }), topMargin(10));

        status = text("", 13, SIGNAL, false);
        root.addView(status, topMargin(16));

        root.addView(button("Infect me", true, v -> start()), topMargin(18));
        root.addView(button("Stop", false, v -> {
            stopService(new Intent(this, OverlayService.class));
            refresh("Stopped. Your screen is clean.");
        }), topMargin(10));

        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh(null);
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            refresh("Step 1 first: allow display over other apps for Trance.exe.");
            return;
        }
        int checked = freqGroup.getCheckedRadioButtonId() - 1000;
        prefs.edit()
                .putInt("freq", Math.max(0, checked))
                .putBoolean("builtin", cbBuiltin.isChecked())
                .putBoolean("words", cbWords.isChecked())
                .putInt("audio", Math.max(0, soundGroup.getCheckedRadioButtonId() - 2000))
                .putInt("beat", Math.max(0, beatGroup.getCheckedRadioButtonId() - 3000))
                .putInt("vol", volBar.getProgress())
                .putString("wordlist", wordsEt.getText().toString())
                .putInt("wp", Math.max(0, wpGroup.getCheckedRadioButtonId() - 4000))
                .apply();
        Set<String> uris = prefs.getStringSet("uris", null);
        boolean none = (uris == null || uris.isEmpty()) && !cbBuiltin.isChecked() && !cbWords.isChecked()
                && soundGroup.getCheckedRadioButtonId() - 2000 == 0;
        if (none) {
            refresh("Turn something on: images, spirals, words or sound.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        final int wp = Math.max(0, wpGroup.getCheckedRadioButtonId() - 4000);
        if (wp == 0) {
            startForegroundService(new Intent(this, OverlayService.class));
            refresh("Running. Switch to any app. Stop here or in the notification.");
            return;
        }
        final String photo = prefs.getString("wp_photo", null);
        if (wp == 2 && photo == null) {
            refresh("Choose a background photo first.");
            return;
        }
        refresh("Saving your wallpaper...");
        new Thread(() -> {
            final String err = WallpaperHelper.prepare(this, wp, photo == null ? null : Uri.parse(photo));
            runOnUiThread(() -> {
                startForegroundService(new Intent(this, OverlayService.class));
                if (err != null) {
                    refresh(err + " Running without the wallpaper change.");
                } else {
                    refresh("Running. Switch to any app. Stop here or in the notification.");
                    if (wp == 1) openSpiralWallpaperPicker();
                }
            });
        }).start();
    }

    private void openSpiralWallpaperPicker() {
        Intent i = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
        i.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, SpiralWallpaperService.class));
        try {
            startActivity(i);
        } catch (Exception e) {
            refresh("Couldn't open the wallpaper picker. Choose Trance.exe under Settings > Wallpaper > Live wallpapers.");
        }
    }

    private void openStorageAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try {
                startActivity(i);
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_STORAGE);
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_WP) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                Uri u = data.getData();
                try {
                    getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {
                }
                prefs.edit().putString("wp_photo", u.toString()).apply();
                refresh("Background photo chosen.");
            }
            return;
        }
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        Set<String> set = new HashSet<>();
        Set<String> old = prefs.getStringSet("uris", null);
        if (old != null) set.addAll(old);
        int added = 0;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                if (keep(clip.getItemAt(i).getUri(), set)) added++;
            }
        } else if (data.getData() != null) {
            if (keep(data.getData(), set)) added++;
        }
        prefs.edit().putStringSet("uris", set).apply();
        refresh(added + " file" + (added == 1 ? "" : "s") + " added. GIFs will animate.");
    }

    private boolean keep(Uri uri, Set<String> set) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        return set.add(uri.toString());
    }

    private void refresh(String msg) {
        Set<String> uris = prefs.getStringSet("uris", null);
        int n = uris == null ? 0 : uris.size();
        String perm = Settings.canDrawOverlays(this) ? "Overlay permission: allowed" : "Overlay permission: not allowed yet";
        String wpAccess = WallpaperHelper.canReadWallpaper(this) ? "allowed" : "not allowed yet";
        String photo = prefs.getString("wp_photo", null) == null ? "none" : "chosen";
        status.setText((msg == null ? "" : msg + "\n") + perm + "\nYour images: " + n
                + "\nWallpaper access: " + wpAccess + "\nBackground photo: " + photo);
    }

    private RadioGroup radios(String[] labels, int baseId, int selected) {
        RadioGroup g = new RadioGroup(this);
        g.setOrientation(RadioGroup.VERTICAL);
        for (int i = 0; i < labels.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(baseId + i);
            rb.setText(labels[i]);
            rb.setTextColor(FG);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            g.addView(rb);
        }
        g.check(baseId + Math.max(0, Math.min(labels.length - 1, selected)));
        return g;
    }

    private CheckBox check(String label, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(FG);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        c.setChecked(on);
        return c;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTextColor(primary ? 0xFF1A0510 : FG);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(primary ? ACCENT : PANEL);
        if (!primary) g.setStroke(dp(1), LINE);
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams topMargin(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(dp);
        return lp;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
