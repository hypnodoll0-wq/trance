package com.trance.exe;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {
    static final String PREFS = "trance";
    private static final int REQ_PICK = 1;
    private static final int REQ_NOTIF = 2;
    private static final int BG = 0xFF0A0714, PANEL = 0xFF150E28, LINE = 0xFF2C2150,
            FG = 0xFFF1ECFF, DIM = 0xFF9A8FC0, ACCENT = 0xFFFF3D9A, SIGNAL = 0xFF35E0C5;
    private static final String[] FREQ = {
            "Slow (every 6 to 12 s)", "Medium (every 3 to 7 s)", "Frequent (every 2 to 4 s)",
            "Rapid (every 1 to 2 s)", "Flood (every 0.6 to 1.2 s)"};

    private SharedPreferences prefs;
    private TextView status;
    private RadioGroup freqGroup;
    private CheckBox cbBuiltin, cbWords;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        sv.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = text("Trance.exe", 36, FG, true);
        SpannableString ss = new SpannableString("Trance.exe");
        ss.setSpan(new ForegroundColorSpan(ACCENT), 6, 10, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        title.setText(ss);
        root.addView(title);

        root.addView(text("A harmless pretend virus. It drops images, GIFs and words over your other "
                + "apps at random moments. Touches pass straight through, so your phone stays usable. "
                + "It ends when the screen turns off or you tap Stop.", 14, DIM, false), topMargin(8));

        root.addView(text("Pop-ups fade in and out slowly and never strobe. Skip this app if "
                + "flashing or spinning visuals bother you.", 13, DIM, false), topMargin(12));

        root.addView(button("1. Allow display over other apps", false, v -> {
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
        }), topMargin(22));

        root.addView(button("2. Add images or GIFs", false, v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType("image/*");
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(i, REQ_PICK);
        }), topMargin(10));

        root.addView(button("Clear my images", false, v -> {
            prefs.edit().remove("uris").apply();
            refresh("Images cleared.");
        }), topMargin(10));

        root.addView(text("HOW OFTEN", 12, DIM, false), topMargin(22));
        freqGroup = new RadioGroup(this);
        freqGroup.setOrientation(RadioGroup.VERTICAL);
        int saved = prefs.getInt("freq", 1);
        for (int i = 0; i < FREQ.length; i++) {
            RadioButton rb = new RadioButton(this);
            rb.setId(1000 + i);
            rb.setText(FREQ[i]);
            rb.setTextColor(FG);
            rb.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
            freqGroup.addView(rb);
        }
        freqGroup.check(1000 + Math.max(0, Math.min(FREQ.length - 1, saved)));
        root.addView(freqGroup, topMargin(4));

        cbBuiltin = check("Include built-in spirals", prefs.getBoolean("builtin", true));
        cbWords = check("Include drifting words", prefs.getBoolean("words", true));
        root.addView(cbBuiltin, topMargin(8));
        root.addView(cbWords, topMargin(2));

        status = text("", 13, SIGNAL, false);
        root.addView(status, topMargin(16));

        root.addView(button("Infect me", true, v -> start()), topMargin(18));
        root.addView(button("Stop", false, v -> {
            stopService(new Intent(this, OverlayService.class));
            refresh("Stopped. Your screen is clean.");
        }), topMargin(10));

        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh(null);
    }

    private void start() {
        if (!Settings.canDrawOverlays(this)) {
            refresh("Step 1 first: allow display over other apps for Trance.exe.");
            return;
        }
        int checked = freqGroup.getCheckedRadioButtonId() - 1000;
        prefs.edit()
                .putInt("freq", Math.max(0, checked))
                .putBoolean("builtin", cbBuiltin.isChecked())
                .putBoolean("words", cbWords.isChecked())
                .apply();
        Set<String> uris = prefs.getStringSet("uris", null);
        boolean none = (uris == null || uris.isEmpty()) && !cbBuiltin.isChecked() && !cbWords.isChecked();
        if (none) {
            refresh("Turn something on: images, spirals or words.");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
        }
        startForegroundService(new Intent(this, OverlayService.class));
        refresh("Running. Switch to any app. Stop here or in the notification.");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null) return;
        Set<String> set = new HashSet<>();
        Set<String> old = prefs.getStringSet("uris", null);
        if (old != null) set.addAll(old);
        int added = 0;
        ClipData clip = data.getClipData();
        if (clip != null) {
            for (int i = 0; i < clip.getItemCount(); i++) {
                if (keep(clip.getItemAt(i).getUri(), set)) added++;
            }
        } else if (data.getData() != null) {
            if (keep(data.getData(), set)) added++;
        }
        prefs.edit().putStringSet("uris", set).apply();
        refresh(added + " file" + (added == 1 ? "" : "s") + " added. GIFs will animate.");
    }

    private boolean keep(Uri uri, Set<String> set) {
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
        return set.add(uri.toString());
    }

    private void refresh(String msg) {
        Set<String> uris = prefs.getStringSet("uris", null);
        int n = uris == null ? 0 : uris.size();
        String perm = Settings.canDrawOverlays(this) ? "Overlay permission: allowed" : "Overlay permission: not allowed yet";
        status.setText((msg == null ? "" : msg + "\n") + perm + "\nYour images: " + n);
    }

    private CheckBox check(String label, boolean on) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(FG);
        c.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        c.setChecked(on);
        return c;
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button button(String label, boolean primary, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        b.setTextColor(primary ? 0xFF1A0510 : FG);
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(10));
        g.setColor(primary ? ACCENT : PANEL);
        if (!primary) g.setStroke(dp(1), LINE);
        b.setBackground(g);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout.LayoutParams topMargin(int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(dp);
        return lp;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
