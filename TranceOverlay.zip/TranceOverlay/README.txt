Trance.exe - Android overlay app

This app draws fading images, GIFs and words over your other apps. Touches pass
through, so the phone stays usable. It stops when the screen turns off, when the
phone shuts down, or when you tap Stop (in the app or in its notification).
It never starts by itself and never restarts after a reboot.

BUILD THE APK (needs a computer)
1. Install Android Studio (free): developer.android.com/studio
2. Unzip this folder. In Android Studio choose File > Open and pick TranceOverlay.
3. Wait for the Gradle sync to finish. The first sync downloads the Android SDK
   pieces it needs; say yes if it asks to install them.
4. Menu: Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate". The file is app/build/outputs/apk/debug/app-debug.apk

INSTALL ON YOUR PHONE (Android 9 or newer)
1. Copy app-debug.apk to your phone and open it from the Files app.
2. Allow installs from that source when Android asks.

USE IT
1. Open Trance.exe and tap "1. Allow display over other apps". Turn it on for
   Trance.exe, then go back.
2. Tap "2. Add images or GIFs" and pick some, or just keep the built-in spirals.
3. Choose how often, then tap "Infect me". Allow notifications if asked, so the
   Stop button shows in the notification shade.
4. Switch to any app. Turn the screen off or tap Stop to end it.

To remove everything: uninstall the app, or turn off its "display over other apps"
permission in Settings.
